# Changelog

## 1.1.0

- Messages can now be more than just 1 word
- Fixed bug that only allowed the host to vote everyone and the other clients only being able to vote themselves

## 1.0.0

- Initial release