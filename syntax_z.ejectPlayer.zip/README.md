# EjectPlayer

<img src=".\assets\ejectPlayer.png" alt="Eject Player Screenshot">

Eject 1 or more unlucky employee(s) out of the ship. This only works when the ship is in space. 
Everyone needs the mod for it to work.


## Commands

- eject (ejects chosen player from ship)
- list (shows every player name and the ID associated with them)

# Example Usage

## Eject

`eject (playerID) (message)`

<img src=".\assets\ejectClip.gif" alt="Eject Player example">


